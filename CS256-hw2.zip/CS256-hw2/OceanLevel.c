/*
 ============================================================================
 Name        : OceanLevel.c
 Author      : 
 Version     :
 Copyright   : Your copyright notice
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>

int main(void) {
	double seaLvl = 11.89; // in meters
	double rising = 0.0015; //1.5mm = 0.0015m
	double temp = seaLvl;


double caclculator(double years) {

		for (int i=0; i < years; i++){
			temp = seaLvl * rising;

			return temp;

		}
    }
}
